
miles_per_gallon = float(input())
dollars_per_gallon = float(input())

dollars_20miles = 20 * dollars_per_gallon * (1.0 / miles_per_gallon)
dollars_75miles = 75 * dollars_per_gallon * (1.0 / miles_per_gallon)
dollars_500miles = 500 * dollars_per_gallon * (1.0 / miles_per_gallon)

print(f'{dollars_20miles:.2f} {dollars_75miles:.2f} {dollars_500miles:.2f}')
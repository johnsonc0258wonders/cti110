is_leap_year = False
   
input_year = int(input())

if input_year % 4 == 0:
    if input_year % 100 == 0:
        if input_year % 400 == 0:
            print('%0.0f - leap year' % input_year)
        else:
            print('%0.0f - not a leap year' % input_year)
    else:
        print('%0.0f - leap year' % input_year)
else:
        print('%0.0f - not a leap year' % input_year)
    
num1 = float(input())
num2 = float(input())
num3 = float(input())
num4 = float(input())


prod_num = (num1 * num2 * num3 * num4)
avg_num = (num1 + num2 + num3 + num4) / 4

print(f'{prod_num:.0f} {avg_num:.0f}')
print(f'{prod_num:.3f} {avg_num:.3f}')